File: readme.txt
Date: July 28, 1997

Description:

	This directory contains HTML and "man" manual pages for SCTK
the "Scoring Toolkit".  The Toolkit includes the programs sclite, sc_stats
and rover.

	The best places to start are: 'sctk.htm', 'sclite.htm',
'sc_stats.htm' and 'rover.htm'.


